import AdminInventory from "./AdminInventory";

export default function AdminDashboard() {
  return <AdminInventory />;
}
